export interface NgTabModel {
    id: string;
    titile: string;
    templateId: string;
}
